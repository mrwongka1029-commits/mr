const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const path = require('path');
const bcrypt = require('bcrypt');

const app = express();
const PORT = process.env.PORT || 3000;

// Models
const User = require('./models/User');
const Film = require('./models/Film');

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static('public'));

// Session configuration
app.use(session({
    secret: 'film-borrow-system-secret-key-2025',
    resave: false,
    saveUninitialized: false,
    cookie: { 
        secure: false, // set to true if using HTTPS
        maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
}));

// EJS setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Database connection
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/film_borrow_system';
mongoose.connect(MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log('✅ Connected to MongoDB'))
.catch(err => console.error('❌ MongoDB connection error:', err));

// Middleware to make user data available to all views
app.use((req, res, next) => {
    res.locals.user = req.session.user || null;
    next();
});

// Middleware to check if user is authenticated
const requireAuth = (req, res, next) => {
    if (req.session.user) {
        next();
    } else {
        res.redirect('/login');
    }
};

// Middleware to check if user is admin
const requireAdmin = (req, res, next) => {
    if (req.session.user && req.session.user.role === 'admin') {
        next();
    } else {
        res.status(403).render('pages/error', { 
            error: 'Access denied. Admin rights required.',
            user: req.session.user
        });
    }
};

// ==================== ROUTES ====================

// Home route - redirect to login
app.get('/', (req, res) => {
    if (req.session.user) {
        res.redirect('/dashboard');
    } else {
        res.redirect('/login');
    }
});

// Login routes
app.get('/login', (req, res) => {
    if (req.session.user) {
        return res.redirect('/dashboard');
    }
    res.render('pages/login', { error: null });
});

app.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        
        // Find user
        const user = await User.findOne({ username });
        if (!user) {
            return res.render('pages/login', { 
                error: 'Invalid username or password' 
            });
        }
        
        // Check password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.render('pages/login', { 
                error: 'Invalid username or password' 
            });
        }
        
        // Store user in session
        req.session.user = {
            id: user._id,
            username: user.username,
            role: user.role
        };
        
        res.redirect('/dashboard');
    } catch (error) {
        console.error('Login error:', error);
        res.render('pages/login', { 
            error: 'An error occurred during login' 
        });
    }
});

// Logout route
app.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error('Logout error:', err);
        }
        res.redirect('/login');
    });
});

// Dashboard route
app.get('/dashboard', requireAuth, async (req, res) => {
    try {
        const totalFilms = await Film.countDocuments();
        const availableFilms = await Film.countDocuments({ available: true });
        const borrowedFilms = await Film.countDocuments({ available: false });
        const userBorrowedFilms = await Film.countDocuments({ 
            borrowedBy: req.session.user.username 
        });
        
        const recentFilms = await Film.find()
            .sort({ createdAt: -1 })
            .limit(6);

        res.render('pages/dashboard', {
            user: req.session.user,
            totalFilms,
            availableFilms,
            borrowedFilms,
            userBorrowedFilms,
            recentFilms
        });
    } catch (error) {
        console.error('Dashboard error:', error);
        res.status(500).render('pages/error', { 
            error: 'Server error',
            user: req.session.user
        });
    }
});

// Films listing with search
app.get('/films', requireAuth, async (req, res) => {
    try {
        const { search, genre, available } = req.query;
        let query = {};
        
        // Build search query
        if (search) {
            query.$or = [
                { title: { $regex: search, $options: 'i' } },
                { director: { $regex: search, $options: 'i' } }
            ];
        }
        
        if (genre && genre !== 'all') {
            query.genre = genre;
        }
        
        if (available && available !== 'all') {
            query.available = available === 'available';
        }
        
        const films = await Film.find(query).sort({ title: 1 });
        const genres = await Film.distinct('genre');
        
        res.render('pages/films', {
            user: req.session.user,
            films,
            genres,
            search: search || '',
            selectedGenre: genre || 'all',
            selectedAvailability: available || 'all'
        });
    } catch (error) {
        console.error('Films error:', error);
        res.status(500).render('pages/error', { 
            error: 'Server error',
            user: req.session.user
        });
    }
});

// Add film form (admin only)
app.get('/films/add', requireAuth, requireAdmin, (req, res) => {
    res.render('pages/add-film', { 
        user: req.session.user,
        error: null 
    });
});

// Create new film (admin only)
app.post('/films/add', requireAuth, requireAdmin, async (req, res) => {
    try {
        const { title, director, genre, releaseYear } = req.body;
        
        // Basic validation
        if (!title || !director || !genre || !releaseYear) {
            return res.render('pages/add-film', {
                user: req.session.user,
                error: 'All fields are required'
            });
        }
        
        const newFilm = new Film({
            title,
            director,
            genre,
            releaseYear: parseInt(releaseYear)
        });
        
        await newFilm.save();
        res.redirect('/films');
    } catch (error) {
        console.error('Add film error:', error);
        res.render('pages/add-film', { 
            user: req.session.user,
            error: 'Error adding film. Please try again.' 
        });
    }
});

// Edit film form (admin only)
app.get('/films/:id/edit', requireAuth, requireAdmin, async (req, res) => {
    try {
        const film = await Film.findById(req.params.id);
        if (!film) {
            return res.status(404).render('pages/error', {
                error: 'Film not found',
                user: req.session.user
            });
        }
        
        res.render('pages/edit-film', {
            user: req.session.user,
            film,
            error: null
        });
    } catch (error) {
        console.error('Edit film error:', error);
        res.status(500).render('pages/error', {
            error: 'Server error',
            user: req.session.user
        });
    }
});

// Update film (admin only)
app.post('/films/:id/edit', requireAuth, requireAdmin, async (req, res) => {
    try {
        const { title, director, genre, releaseYear } = req.body;
        
        await Film.findByIdAndUpdate(req.params.id, {
            title,
            director,
            genre,
            releaseYear: parseInt(releaseYear)
        });
        
        res.redirect('/films');
    } catch (error) {
        console.error('Update film error:', error);
        res.render('pages/edit-film', {
            user: req.session.user,
            film: { _id: req.params.id, ...req.body },
            error: 'Error updating film. Please try again.'
        });
    }
});

// Delete film (admin only)
app.post('/films/:id/delete', requireAuth, requireAdmin, async (req, res) => {
    try {
        await Film.findByIdAndDelete(req.params.id);
        res.redirect('/films');
    } catch (error) {
        console.error('Delete film error:', error);
        res.status(500).render('pages/error', {
            error: 'Error deleting film',
            user: req.session.user
        });
    }
});

// Borrow film
app.post('/films/:id/borrow', requireAuth, async (req, res) => {
    try {
        const film = await Film.findById(req.params.id);
        
        if (!film) {
            return res.status(404).render('pages/error', {
                error: 'Film not found',
                user: req.session.user
            });
        }
        
        if (!film.available) {
            return res.status(400).render('pages/error', {
                error: 'Film is already borrowed',
                user: req.session.user
            });
        }
        
        film.available = false;
        film.borrowedBy = req.session.user.username;
        film.borrowDate = new Date();
        film.dueDate = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000); // 14 days from now
        
        await film.save();
        res.redirect('/films');
    } catch (error) {
        console.error('Borrow error:', error);
        res.status(500).render('pages/error', {
            error: 'Server error',
            user: req.session.user
        });
    }
});

// Return film
app.post('/films/:id/return', requireAuth, async (req, res) => {
    try {
        const film = await Film.findById(req.params.id);
        
        if (!film) {
            return res.status(404).render('pages/error', {
                error: 'Film not found',
                user: req.session.user
            });
        }
        
        if (film.available) {
            return res.status(400).render('pages/error', {
                error: 'Film is not borrowed',
                user: req.session.user
            });
        }
        
        // Check if user is the one who borrowed it or is admin
        if (film.borrowedBy !== req.session.user.username && req.session.user.role !== 'admin') {
            return res.status(403).render('pages/error', {
                error: 'You can only return films you borrowed',
                user: req.session.user
            });
        }
        
        film.available = true;
        film.borrowedBy = null;
        film.borrowDate = null;
        film.dueDate = null;
        
        await film.save();
        res.redirect('/films');
    } catch (error) {
        console.error('Return error:', error);
        res.status(500).render('pages/error', {
            error: 'Server error',
            user: req.session.user
        });
    }
});

// My borrowed films
app.get('/my-films', requireAuth, async (req, res) => {
    try {
        const borrowedFilms = await Film.find({ 
            borrowedBy: req.session.user.username 
        }).sort({ borrowDate: -1 });
        
        res.render('pages/my-films', {
            user: req.session.user,
            films: borrowedFilms
        });
    } catch (error) {
        console.error('My films error:', error);
        res.status(500).render('pages/error', {
            error: 'Server error',
            user: req.session.user
        });
    }
});

// ==================== RESTful APIs (No Authentication Required) ====================

// GET /api/films - Get all films (with optional query parameters)
app.get('/api/films', async (req, res) => {
    try {
        const { search, genre, available, director } = req.query;
        let query = {};
        
        if (search) {
            query.title = { $regex: search, $options: 'i' };
        }
        
        if (genre) {
            query.genre = genre;
        }
        
        if (available) {
            query.available = available === 'true';
        }
        
        if (director) {
            query.director = { $regex: director, $options: 'i' };
        }
        
        const films = await Film.find(query);
        res.json({
            success: true,
            count: films.length,
            data: films
        });
    } catch (error) {
        console.error('API films error:', error);
        res.status(500).json({
            success: false,
            error: 'Server error'
        });
    }
});

// GET /api/films/:id - Get specific film
app.get('/api/films/:id', async (req, res) => {
    try {
        const film = await Film.findById(req.params.id);
        if (!film) {
            return res.status(404).json({
                success: false,
                error: 'Film not found'
            });
        }
        
        res.json({
            success: true,
            data: film
        });
    } catch (error) {
        console.error('API film detail error:', error);
        res.status(500).json({
            success: false,
            error: 'Server error'
        });
    }
});

// POST /api/films - Create new film
app.post('/api/films', async (req, res) => {
    try {
        const { title, director, genre, releaseYear } = req.body;
        
        if (!title || !director || !genre || !releaseYear) {
            return res.status(400).json({
                success: false,
                error: 'All fields (title, director, genre, releaseYear) are required'
            });
        }
        
        const newFilm = new Film({
            title,
            director,
            genre,
            releaseYear: parseInt(releaseYear)
        });
        
        await newFilm.save();
        
        res.status(201).json({
            success: true,
            data: newFilm
        });
    } catch (error) {
        console.error('API create film error:', error);
        res.status(500).json({
            success: false,
            error: 'Server error'
        });
    }
});

// PUT /api/films/:id - Update film
app.put('/api/films/:id', async (req, res) => {
    try {
        const { title, director, genre, releaseYear } = req.body;
        
        const updatedFilm = await Film.findByIdAndUpdate(
            req.params.id,
            {
                title,
                director,
                genre,
                releaseYear: releaseYear ? parseInt(releaseYear) : undefined
            },
            { new: true, runValidators: true }
        );
        
        if (!updatedFilm) {
            return res.status(404).json({
                success: false,
                error: 'Film not found'
            });
        }
        
        res.json({
            success: true,
            data: updatedFilm
        });
    } catch (error) {
        console.error('API update film error:', error);
        res.status(500).json({
            success: false,
            error: 'Server error'
        });
    }
});

// DELETE /api/films/:id - Delete film
app.delete('/api/films/:id', async (req, res) => {
    try {
        const deletedFilm = await Film.findByIdAndDelete(req.params.id);
        
        if (!deletedFilm) {
            return res.status(404).json({
                success: false,
                error: 'Film not found'
            });
        }
        
        res.json({
            success: true,
            message: 'Film deleted successfully',
            data: deletedFilm
        });
    } catch (error) {
        console.error('API delete film error:', error);
        res.status(500).json({
            success: false,
            error: 'Server error'
        });
    }
});

// PUT /api/films/:id/borrow - Borrow a film
app.put('/api/films/:id/borrow', async (req, res) => {
    try {
        const film = await Film.findById(req.params.id);
        
        if (!film) {
            return res.status(404).json({
                success: false,
                error: 'Film not found'
            });
        }
        
        if (!film.available) {
            return res.status(400).json({
                success: false,
                error: 'Film is already borrowed'
            });
        }
        
        film.available = false;
        film.borrowedBy = req.body.username || 'api-user';
        film.borrowDate = new Date();
        film.dueDate = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000);
        
        await film.save();
        
        res.json({
            success: true,
            message: 'Film borrowed successfully',
            data: film
        });
    } catch (error) {
        console.error('API borrow film error:', error);
        res.status(500).json({
            success: false,
            error: 'Server error'
        });
    }
});

// PUT /api/films/:id/return - Return a film
app.put('/api/films/:id/return', async (req, res) => {
    try {
        const film = await Film.findById(req.params.id);
        
        if (!film) {
            return res.status(404).json({
                success: false,
                error: 'Film not found'
            });
        }
        
        if (film.available) {
            return res.status(400).json({
                success: false,
                error: 'Film is not borrowed'
            });
        }
        
        film.available = true;
        film.borrowedBy = null;
        film.borrowDate = null;
        film.dueDate = null;
        
        await film.save();
        
        res.json({
            success: true,
            message: 'Film returned successfully',
            data: film
        });
    } catch (error) {
        console.error('API return film error:', error);
        res.status(500).json({
            success: false,
            error: 'Server error'
        });
    }
});

// ==================== ERROR HANDLING ====================

// 404 handler
app.use((req, res) => {
    res.status(404).render('pages/error', {
        error: 'Page not found',
        user: req.session.user
    });
});

// Error handler
app.use((err, req, res, next) => {
    console.error('Unhandled error:', err);
    res.status(500).render('pages/error', {
        error: 'Internal server error',
        user: req.session.user
    });
});

// ==================== DATA INITIALIZATION ====================

async function initializeData() {
    try {
        // Check if admin user exists
        const adminExists = await User.findOne({ username: 'admin' });
        if (!adminExists) {
            const adminUser = new User({
                username: 'admin',
                password: 'admin123', // Will be hashed automatically by the pre-save hook
                email: 'admin@filmlibrary.com',
                role: 'admin'
            });
            await adminUser.save();
            console.log('✅ Admin user created');
        }

        // Check if regular user exists
        const userExists = await User.findOne({ username: 'user1' });
        if (!userExists) {
            const regularUser = new User({
                username: 'user1',
                password: 'password123',
                email: 'user1@filmlibrary.com',
                role: 'member'
            });
            await regularUser.save();
            console.log('✅ Regular user created');
        }

        // Add sample films if none exist
        const filmCount = await Film.countDocuments();
        if (filmCount === 0) {
            const sampleFilms = [
                {
                    title: "The Shawshank Redemption",
                    director: "Frank Darabont",
                    genre: "Drama",
                    releaseYear: 1994
                },
                {
                    title: "The Godfather",
                    director: "Francis Ford Coppola",
                    genre: "Crime",
                    releaseYear: 1972
                },
                {
                    title: "The Dark Knight",
                    director: "Christopher Nolan",
                    genre: "Action",
                    releaseYear: 2008
                },
                {
                    title: "Pulp Fiction",
                    director: "Quentin Tarantino",
                    genre: "Crime",
                    releaseYear: 1994
                },
                {
                    title: "Forrest Gump",
                    director: "Robert Zemeckis",
                    genre: "Drama",
                    releaseYear: 1994
                },
                {
                    title: "Inception",
                    director: "Christopher Nolan",
                    genre: "Sci-Fi",
                    releaseYear: 2010
                }
            ];
            
            await Film.insertMany(sampleFilms);
            console.log('✅ Sample films added');
        }
        
        console.log('✅ Data initialization completed');
    } catch (error) {
        console.error('❌ Data initialization error:', error);
    }
}

// ==================== START SERVER ====================

app.listen(PORT, async () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
    console.log('📊 Initializing data...');
    await initializeData();
    console.log('✅ Server is ready!');
});

module.exports = app;